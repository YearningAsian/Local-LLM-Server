Core functions extracted from Streamlit UI.

These are UI-agnostic helpers used by desktop_app.
